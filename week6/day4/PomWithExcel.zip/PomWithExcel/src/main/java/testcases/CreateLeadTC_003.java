package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLeadTC_003 extends ProjectSpecificMethod {

	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cname, String fname, String lname, String phno) {
		
		new LoginPage(driver)
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsTab()
		.clickCreateLead()
		.enterCompanyName(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.enterPhno(phno)
		.clickSubmitButton();
	}
	
	@BeforeTest
	public void setData() {
		excelFileName = "CreateLead";
	}
	
}
