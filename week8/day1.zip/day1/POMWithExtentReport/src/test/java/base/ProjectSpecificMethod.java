 package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{
//public static RemoteWebDriver driver;
	public static Properties prop;
	public static  ExtentReports extent;
	public String testName, testDescription, author, category;
//	public static ExtentTest test, node;
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	
	public static final ThreadLocal<ExtentTest> parentTest = new ThreadLocal<ExtentTest>();
	public static final ThreadLocal<ExtentTest> nodeTest = new ThreadLocal<ExtentTest>();
	public static final ThreadLocal <String> testCaseName = new ThreadLocal<String>();
	
	public void setDriver() {
		rd.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
	
		return rd.get();
	}

	
	
	
// Driver	
	@BeforeMethod
	public void preCondition() throws IOException {
//		driver = new ChromeDriver();
		setTest();
		prop = new Properties();
		FileInputStream file = new FileInputStream("./src/test/resources/english.properties");
		prop.load(file);
		
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/");
		
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	
	
	// Report
	
	@BeforeSuite
	public void startReport() {
		//Report path
				ExtentHtmlReporter reporter = new ExtentHtmlReporter("report/result.html");
				
				// create report
				extent = new ExtentReports();
				
				// Maintain the existing report
				reporter.setAppendExisting(true);
				
				// Attach the report into the reporter path
				extent.attachReporter(reporter);
	}
	
	// Information about testcase
	@BeforeClass
	public void testcaseDetails() {
		ExtentTest test = extent.createTest(testName,testDescription);
		test.assignAuthor(author);
		test.assignCategory(category);
		parentTest.set(test);
		testCaseName.set(testName);
//		node = test.createNode(testName);
		
	}
	
	public String getTestCaseName() {
		return testCaseName.get();
	}
	
	public void setTest() {
		ExtentTest node = parentTest.get().createNode(getTestCaseName());
		nodeTest.set(node);
	}
	
	// msg --> description of my test Step
	// Status --> pass/fail
	public void reportStep(String msg, String status) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			nodeTest.get().pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			nodeTest.get().fail(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		
	}
	
	public String takeSnap() throws IOException {
		//Generate a random number
		int randomNum =  (int) ((Math.random()*9999)+999);
		LocalDateTime now = LocalDateTime.now();
		String replaceAll = now.toString().replaceAll("[^0-9]", "");
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File des = new File("./snaps/img"+replaceAll+".png");
		FileUtils.copyFile(src, des);
		return replaceAll;
	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
}
