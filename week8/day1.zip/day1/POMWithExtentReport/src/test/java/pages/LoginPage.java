package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {
	
	
	

	@Given ("Enter the username")
	public LoginPage enterUsername() throws IOException {
		System.out.println("LoginPage : " + getDriver());
		
		try {
			getDriver().findElement(By.id("username")).sendKeys((String) prop.get("username"));
//			test.pass("Username entered successfully", MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img1.png").build());
			reportStep("Username entered successfully", "pass");
		} catch (Exception e) {
//			test.fail("Unable to enter the username ", MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img2.png").build());
			reportStep(e+" Unable to enter the username", "fail");
		}
//		LoginPage lp  = new LoginPage();
//		return lp ;
		return this;
	}
	
	@Given ("Enter the password")
	public LoginPage enterPassword() throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys((String) prop.get("password"));
			reportStep("Password enter successfully", "pass");
		} catch (Exception e) {
			reportStep("unable to enter the password", "fail");
		}
//		LoginPage lp  = new LoginPage();
//		return lp ;
//		return new LoginPage();
		return this;
	}
	
	@When ("Click on the Login button")
	public WelcomePage clickLoginButton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button clicked successfuly", "pass");
		} catch (Exception e) {
			reportStep("Unable to click login button", "fail");
		}
//		WelcomePage wp = new WelcomePage();
//		return wp;
		return new WelcomePage();
	}

}
