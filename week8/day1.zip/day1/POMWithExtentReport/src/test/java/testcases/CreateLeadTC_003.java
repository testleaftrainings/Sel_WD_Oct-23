package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLeadTC_003 extends ProjectSpecificMethod {

	
	@Test
	public void runCreateLead() throws IOException {
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsTab()
		.clickCreateLead()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.enterPhno()
		.clickSubmitButton();
	}
	
	@BeforeTest
	public void setDetails() {
		testName = "Create Lead TC_003";
		testDescription = "Create a lead with positive functionality";
		author = "Gokul";
		category = "functional";
	}
	
}
