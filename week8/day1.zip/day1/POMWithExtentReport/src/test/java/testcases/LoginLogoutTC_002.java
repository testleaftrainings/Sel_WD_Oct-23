package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class LoginLogoutTC_002 extends ProjectSpecificMethod{

	
	@Test
	public void runLogout() throws IOException {
		/*
		 * LoginPage lp = new LoginPage(); lp.enterUsername() .enterPassword()
		 */
		System.out.println("Logout :  " + getDriver());
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLogoutButton();
		
	}
	
	@BeforeTest
	public void setDetails() {
		testName = "LoginLogoutTC_002";
		testDescription = "LoginLogout with positive functionality";
		author = "Gokul";
		category = "functional";
	}
}
